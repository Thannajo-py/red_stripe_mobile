package com.example.filrouge

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import com.example.filrouge.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity(), View.OnClickListener {

    val binding: ActivityMainBinding by lazy{ ActivityMainBinding.inflate(layoutInflater) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setContentView(binding.root)
        binding.btnLogin.setOnClickListener(this)
    }

    override fun onClick(v: View?) {

        binding.tvLoginError.visibility = View.GONE
        binding.progressBarLogin.visibility = View.VISIBLE

        if (binding.etLogin.text.toString() == "test" && binding.etPassword.text.toString() == "test"){
            startActivity(Intent(this, MainMenuActivity::class.java))
        }
        else{
            binding.tvLoginError.text = "Wrong login or password"
            binding.tvLoginError.visibility = View.VISIBLE
        }
        binding.progressBarLogin.visibility = View.GONE
    }
}