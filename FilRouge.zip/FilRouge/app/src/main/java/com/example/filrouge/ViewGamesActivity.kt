package com.example.filrouge

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.LinearLayout
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.filrouge.databinding.ActivityMainMenuBinding
import com.example.filrouge.databinding.ActivityViewGamesBinding
import com.google.gson.Gson
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.lang.Exception

class ViewGamesActivity : AppCompatActivity(), View.OnClickListener, GameAdapter.onGameListListener {


    val binding: ActivityViewGamesBinding by lazy{ ActivityViewGamesBinding.inflate(layoutInflater) }
    val gson = Gson()
    val adapter = GameAdapter(allGames, this)


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view_games)
        setContentView(binding.root)
        binding.btnSynchronize.setOnClickListener(this)
        binding.rvGames.adapter = adapter
        binding.rvGames.layoutManager = GridLayoutManager(this, 1)
        binding.rvGames.addItemDecoration(MarginItemDecoration(5))

    }


    override fun onClick(v: View?) {
        binding.progressBar.visibility = View.VISIBLE
        binding.btnSynchronize.isClickable = false
        binding.tvGameError.visibility = View.GONE


        CoroutineScope(SupervisorJob()).launch {
            try {
                val result = gson.fromJson(
                    sendGetOkHttpRequest(APIUrl.ALL_GAMES.url),
                    ApiResponse::class.java
                )

                allGames.clear()
                allGames.addAll(result.games)

                allAddOns.clear()
                allAddOns.addAll(result.add_ons)

                allMultiAddOns.clear()
                allMultiAddOns.addAll(result.multi_add_ons)

                runOnUiThread {
                    adapter.notifyDataSetChanged()
                    binding.progressBar.visibility = View.GONE
                    binding.btnSynchronize.isClickable = true
                }

            } catch (e: Exception) {
                e.printStackTrace()
                runOnUiThread {
                    binding.tvGameError.text = "error: ${e.message}"
                    binding.tvGameError.visibility = View.VISIBLE
                    binding.progressBar.visibility = View.GONE
                    binding.btnSynchronize.isClickable = true
                }
            }
        }
    }


    override fun onGameClick(datum: GameBean) {
        intent = Intent(this, GameDetails::class.java)
        intent.putExtra(SerialKey.Game.name, datum)
        startActivity(intent)
    }


}